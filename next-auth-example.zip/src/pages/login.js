import { useState } from 'react';
import { signIn,signOut,useSession } from 'next-auth/react';
import axios from 'axios';
import './login.css';

export default function Home() {
  const { data: session, status } = useSession();
  const [rememberMe, setRememberMe] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = async (e) => {
    e.preventDefault(); 
    try {
      const response = await signIn('credentials', {
        username,
        password,
        remember: rememberMe ? '1' : '0',
      });
      if (response.error) {
        console.error(response.error);
      } else if (response.ok) {
        console.log('Sign-in successful');
      }
      if (response.status === 'authenticated') {
        console.log('User is authenticated');
      }
    } catch (error) {
      console.error(error);
    }
  };
  const handleFetchUser = async () => {
    try {
      const response = await axios.get('/api/user');
      console.log(response.data.user);
    } catch (error) {
      console.error(error);
    }
  };
  if (status === 'loading') {
    return <p>Loading...</p>;
  }
  console.log(session);
  // ...rest of your code...
  return (
    <div>
      {!session ? (
         <form onSubmit={handleSignIn}>
           <div className="auth-form">
           <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <label className="remember-me">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
              />
              Remember Me
            </label>
            <button type="submit">Sign In</button>
          </div>
        </form>
      ) : (
        <>
        <div className='admin_area'>
          <p>Welcome, {session.user.name}!</p>
          <button onClick={() => signOut()}>Sign Out</button>
          <button onClick={handleFetchUser}>Fetch User Data</button>
        </div>
       </>
      )}
    </div>
  );
}
