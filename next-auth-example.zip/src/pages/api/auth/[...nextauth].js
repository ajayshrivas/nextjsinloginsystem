import NextAuth from 'next-auth';
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from 'bcryptjs';
import connectDB from '../../../utils/db';
import User from '../../../models/user';

export default NextAuth({
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        username: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
        remember: { label: 'Remember', type: 'checkbox' },
      },
      authorize: async (credentials) => {
        console.log(credentials);
        // You should implement your own authentication logic here.
        // For this example, we're using a hardcoded user.
        //
        await connectDB(); 
        let email = credentials.username
        const user = await User.findOne({ email });
        if (!user) {
          //return res.status(404).json({ message: 'User not found' });
          let error = { message: 'User not found' };
          return Promise.resolve(error);
        }
        const passwordMatch = 1; //await bcrypt.compare(password, credentials.password);
        // if (credentials.username === 'john' && credentials.password === 'password') {
        if(passwordMatch){
          //const user = { id: 1, name: 'John' };
          return Promise.resolve(user);
        } else {
          return Promise.resolve(null);
        }
      },
    }), 
  ],
  session: {
    jwt: true,
  },
});