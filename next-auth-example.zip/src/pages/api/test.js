export default function login(req,res){

    console.log("This is testing..");
    return res.status(200).json({message:'This is testing api'}) 
}